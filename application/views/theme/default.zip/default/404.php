<div class="container">
	<section class="page404" style="margin-top: 100px;">
	    <p class="line1"><?php echo trans('404'); ?></p>
	    <p class="line2"><?php echo trans('look_like_something_wrong'); ?></p>
	    <p><a href="<?php echo base_url(); ?>" class="btn btn-success"><?php echo trans('back_to_home'); ?></a></p>
	    <div><img src="<?php echo base_url('assets/theme/default/images/404.jpg'); ?>" alt="<?php echo trans('404'); ?>"></div>
	</section>
</div>

