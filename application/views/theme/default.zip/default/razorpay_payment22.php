<form action="verify.php" method="POST">
  <script
    src="https://checkout.razorpay.com/v1/checkout.js"
    data-key="rzp_test_XJh9ABDQ0x1UQV"
    data-amount="2000"
    data-currency="INR"
    data-name="rtyrtyrty"
    data-image="rtyrty"
    data-description="rtyrtygfhfgh"
    data-prefill.name="rtyrtyrtyrty"
    data-prefill.email="rtyrtyrty@djshfjdsf.com"
    data-prefill.contact="99999999999999"
    data-notes.shopping_order_id="3456"
  >
  </script>
  <!-- Any extra fields to be submitted with the form but not sent to Razorpay -->
  <input type="hidden" name="shopping_order_id" value="3456">
</form>